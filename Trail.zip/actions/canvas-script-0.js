let root = this;

root.stop();